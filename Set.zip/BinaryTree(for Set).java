import java.util.ArrayList;

class BinaryTreeNode<TValue extends Comparable>
{
	private TValue value;
	private BinaryTreeNode left;
	private BinaryTreeNode right;
	
    public BinaryTreeNode(TValue value)
    {
        this.value = value;
    }
    public TValue getValue()
    {
    	return value;
    }
    public void setLeft(BinaryTreeNode node) 
    {
    	left = node;
    }
    public BinaryTreeNode getLeft() 
    {
    	return left;
    }
    public void setRight(BinaryTreeNode node) 
    {
    	right = node;
    }
    public BinaryTreeNode getRight()
    {
    	return right;
    }
}

class BinaryTree<TValue extends Comparable>
{
	private BinaryTreeNode<TValue> root;
	
	public void add(TValue value) 
    {
        if (root == null)
        {
        	root = new BinaryTreeNode(value);
        }
        else
        {
        	addTo(root, value);
        }
    }
    
    private void addTo(BinaryTreeNode node, TValue value)
    {
    	if (value.compareTo(node.getValue()) < 0)
    	{
    		if (node.getLeft() == null)
    		{
    			node.setLeft(new BinaryTreeNode(value));
    		}
    		else
    		{
    			addTo(node.getLeft(), value);
    		}
    	}
    	else if (value.compareTo(node.getValue()) > 0)
    	{
    		if (node.getRight() == null)
    		{
    			node.setRight(new BinaryTreeNode(value));
    		}
    		else
    		{
    			addTo(node.getRight(), value);
    		}
    	}
    }
    public BinaryTreeNode getRoot() 
    {
    	return root;
    }
    public BinaryTreeNode findNode(TValue value)
    {
    	NodeWithParent maybeResult = findNodeWithParentIn(root, value, null);
    	if (maybeResult == null)
    	{
    		return null;
    	}
    	else
    	{
    		return maybeResult.getNode();
    	}
    }
    private NodeWithParent findNodeWithParentIn(BinaryTreeNode node, TValue value, BinaryTreeNode parent)
    {
    	if (node == null)
    	{
    		return null;
    	}
    	else if (value.compareTo(node.getValue()) == 0)
    	{
    		return new NodeWithParent(node, parent);
    	}
    	else if (value.compareTo(node.getValue()) < 0)
    	{
    		return findNodeWithParentIn(node.getLeft(), value, node);
    	}
    	else 
    	{
    		return findNodeWithParentIn(node.getRight(), value, node);
    	}
    }
    private NodeWithParent findNodeWithParent(TValue value) 
    {
    	return findNodeWithParentIn(root, value, null);
    }
    public Boolean remove(TValue value) 
	{
    	NodeWithParent nodeWithParent = findNodeWithParent(value);
    	if (nodeWithParent == null)
    	{
        	return false;
    	}
    	BinaryTreeNode current = nodeWithParent.getNode();
    	BinaryTreeNode parent = nodeWithParent.getParent();
    	if (current.getRight() == null)
    	{
        	if (parent == null)
        	{
        		root = current.getLeft();
        	}
        	else
        	{
            	int result = parent.getValue().compareTo(current.getValue());
            	if (result > 0)
            	{
                	parent.setLeft(current.getLeft());
            	}
            	else if (result < 0)
            	{
            		parent.setRight(current.getLeft());
            	}	
        	}
    	}
        else if (current.getRight().getLeft() == null)
        {
        	current.getRight().setLeft(current.getLeft());
            if (parent == null)
            {
                root = current.getRight();
            }
            else
            {
                int result = parent.getValue().compareTo(current.getValue());
                if (result > 0)
            	{
                	parent.setLeft(current.getRight());
            	}
            	else if (result < 0)
            	{
            		parent.setRight(current.getRight());
            	}
    		}
		}
        else
        {
            BinaryTreeNode leftmost = current.getRight().getLeft();
            BinaryTreeNode leftmostParent = current.getRight();
            while (leftmost.getLeft() != null)
            {
                leftmostParent = leftmost;
                leftmost = leftmost.getLeft();
            }
            leftmostParent.setLeft(leftmost.getRight());
            leftmost.setLeft(current.getLeft());
            leftmost.setRight(current.getRight());
            if (parent == null)
            {
                root = leftmost;
            }
            else
            {
                int result = parent.getValue().compareTo(current.getValue());
                if (result > 0)
            	{
                	parent.setLeft(leftmost);
            	}
            	else if (result < 0)
            	{
                	parent.setRight(leftmost);
            	}
        	}
    	}
		return true;
	}
	public Boolean contains(TValue value)
	{
	    return findNode(value) != null;
	}
	public ArrayList<TValue> toArrayList()
	{
	    ArrayList result = new ArrayList();
	    fillArrayListFromNode(root, result);
	    return result;
	}
	public void fillArrayListFromNode(BinaryTreeNode node, ArrayList list)
	{
	    if (node == null)
	    {
	        return;
	    }
	    list.add(node.getValue());
	    fillArrayListFromNode(node.getLeft(), list);
	    fillArrayListFromNode(node.getRight(), list);
	}
}

class NodeWithParent 
{
	private BinaryTreeNode node;
	private BinaryTreeNode parent;
	public NodeWithParent(BinaryTreeNode node, BinaryTreeNode parent)
	{
		this.node = node;
		this.parent = parent;
	}
	public BinaryTreeNode getNode()
	{
		return node;
	}
	public BinaryTreeNode getParent()
	{
		return parent;
	}
}