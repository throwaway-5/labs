import java.util.ArrayList;

public class Main {
	public static void main(String[] args)
	{
        Set set = new Set();
        set.add(10);
        set.add(5);
        set.add(7);
        set.add(8);
        set.add(6);
        System.out.println("Contains 8: " + set.contains(8));
        System.out.println("Contains 7: " + set.contains(7));
        System.out.println("Contains 10: " + set.contains(10));
        System.out.println("Contains 2: " + set.contains(2));
        System.out.println("");
        
        System.out.println("Union check");
        Set set1 = new Set();
        set1.add(1);
        set1.add(2);
        set1.add(3);
        set1.add(4);
        Set set2 = new Set();
        set2.add(3);
        set2.add(4);
        set2.add(5);
        set2.add(6);
        Set<Integer> union = set1.union(set2); // проверка объединения
        for(Integer v: union.toArrayList())
        {
            System.out.print("" + v + ", ");
        }
        System.out.println("");
        
        
        System.out.println("Intersection check"); // проверка пересечения
        Set<Integer> intersection = set1.intersection(set2);
        for(Integer v: intersection.toArrayList())
        {
            System.out.print("" + v + ", ");
        }
        System.out.println("");
        
        System.out.println("Difference check"); // проверка разницы
        Set<Integer> difference = set1.difference(set2);
        for(Integer v: difference.toArrayList())
        {
            System.out.print("" + v + ", ");
        }
        System.out.println("");
        
        System.out.println("Symmetric Difference check"); // проверка симметричной разницы
        Set<Integer> symmetricDifference = set1.symmetricDifference(set2);
        for(Integer v: symmetricDifference.toArrayList())
        {
            System.out.print("" + v + ", ");
        }
        System.out.println("");
	}
}
class Set<TValue extends Comparable> // класс множества
{
	private BinaryTree<TValue> tree;
	public Set() // вывод множества
	{
	    tree = new BinaryTree();
	}
	public Set(ArrayList<TValue> list) // добавление всех элементов в множество
	{
	    tree = new BinaryTree();
	    for(TValue v: list)
	    {
	        tree.add(v);
	    }
	}
	public void add(TValue value) // добавление элемента в множество
	{
	    tree.add(value);
	}
	public Boolean contains(TValue value) // проверка содержится ли данный элемент в множестве
	{
	    return tree.contains(value);
	}
	public Boolean remove(TValue value) // удаление элемента из множества
	{
	    return tree.remove(value);
	}
	public ArrayList<TValue> toArrayList() // вывод множества
	{
	    return tree.toArrayList();
	}
	public Set<TValue> union(Set<TValue> other) // объединение
	{
	    Set<TValue> result = new Set(toArrayList());
	    for(TValue v: other.toArrayList())
	    {
	        if (!contains(v))
	        {
	            result.add(v);
	        }
	    }
	    return result;
	}
	public Set<TValue> intersection(Set<TValue> other) // пересечение
	{
	    Set<TValue> result = new Set();
	    for(TValue v: toArrayList())
	    {
	        if (other.contains(v))
	        {
	            result.add(v);
	        }
	    }
	    return result;
	}
	public Set<TValue> difference(Set<TValue> other) // разница
	{
	    Set<TValue> result = new Set(toArrayList());
	    for(TValue v: other.toArrayList())
	    {
	        result.remove(v);
	    }
	    return result;
	}
	public Set<TValue> symmetricDifference(Set<TValue> other) // симметричная разница
	{
	    Set union = union(other);
	    Set intersection = intersection(other);
	    return union.difference(intersection);
	}
}